/**
 * 
 */
/**
 * 
 */
module CameraRentApp {
}